@extends('admin/layouts.master')
@section('title', 'View Course - Admin')
@section('body')

<section class="content">

	@include('admin.course.partial.index')
      	
</section>

@endsection
  